# Texture-Synthesis
## Texture Synthesis by Non-parametric Sampling
This project performs texture synthesis by the algorithm described in "Texture Synthesis by Non-parametric Sampling", by Efros and Leung from ICCV 1999.
