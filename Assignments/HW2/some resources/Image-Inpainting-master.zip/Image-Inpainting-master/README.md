# Image-Inpainting
Image inpaiting using texture syntesis algorithm described in "Texture Synthesis by Non-parametric Sampling", by Efros and Leung from ICCV 1999.
See the report for results and details.
